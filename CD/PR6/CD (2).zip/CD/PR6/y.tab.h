#ifndef _yy_defines_h_
#define _yy_defines_h_

#define ZERO 257
#define ONE 258
#define TWO 259
#define NL 260

#endif /* _yy_defines_h_ */
