#ifndef _yy_defines_h_
#define _yy_defines_h_

#define NUMBER 257

#endif /* _yy_defines_h_ */
