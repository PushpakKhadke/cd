#ifndef _yy_defines_h_
#define _yy_defines_h_

#define ONE 257
#define ZERO 258
#define NL 259

#endif /* _yy_defines_h_ */
